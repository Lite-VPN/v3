from kyt import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw1:
			await event.respond("**Limit-ip:**")
			pw1 = pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw1 = (await pw1).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Expaired:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | bot-add-tro'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Klik Link di atas untuk membuka Detail Account** `{user}` **Successfully Created**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**🧿   𝗫𝗥𝗔𝗬/𝗧𝗥𝗢𝗝𝗔𝗡 𝗔𝗖𝗖𝗢𝗨𝗡𝗧    🧿**
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗥𝗲𝗺𝗮𝗿𝗸𝘀     :** `{remarks}`
**» 𝗛𝗼𝘀𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 :** `{domain}`
**» 𝗛𝗼𝘀𝘁 𝗫𝗿𝗮𝘆𝗗𝗡𝗦:** `{HOST}`
**» 𝗨𝘀𝗲𝗿 𝗤𝘂𝗼𝘁𝗮  :** `Unlimited`
**» 𝗣𝗼𝗿𝘁 𝗗𝗡𝗦    :** `443, 53`
**» 𝗽𝗼𝗿𝘁 𝗧𝗟𝗦    :** `222-1000`
**» 𝗣𝗮𝘁𝗵 𝗧𝗿𝗼𝗷𝗮𝗻 :** `(/multi path)/trojan-ws`
**» 𝗨𝘀𝗲𝗿 𝗜𝗗     :** `{uuid}`
**» 𝗣𝘂𝗯 𝗞𝗲𝘆     :** {PUB}
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗪𝗦    :** 
`{b[0].replace(" ","")}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗚𝗥𝗣𝗖  :** 
`{b[1].replace(" ","")}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗙𝗼𝗿𝗺𝗮𝘁 𝗢𝗽𝗲𝗻𝗖𝗹𝗮𝘀𝗵 : https://{domain}:81/trojan-{user}.txt
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗨𝗻𝘁𝗶𝗹:** `{later}`
**» 🍄@LITE_VERMILION**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#LOCK trojan
@bot.on(events.CallbackQuery(data=b'lock-trojan'))
async def lock_trojan(event):
	async def lock_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK trojan
@bot.on(events.CallbackQuery(data=b'unlock-trojan'))
async def unlock_trojan(event):
	async def unlock_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Trojan**
**» 🍄@LITE_VERMILION**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Minutes:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-trialtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Klik Link di atas untuk membuka Detail Account Trial**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			remarks = re.search("#(.*)",b[0]).group(1)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**🧿   𝗫𝗥𝗔𝗬/𝗧𝗥𝗢𝗝𝗔𝗡 𝗔𝗖𝗖𝗢𝗨𝗡𝗧    🧿**
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗥𝗲𝗺𝗮𝗿𝗸𝘀     :** `{remarks}`
**» 𝗛𝗼𝘀𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 :** `{domain}`
**» 𝗛𝗼𝘀𝘁 𝗫𝗿𝗮𝘆𝗗𝗡𝗦:** `{HOST}`
**» 𝗨𝘀𝗲𝗿 𝗤𝘂𝗼𝘁𝗮  :** `Unlimited`
**» 𝗣𝗼𝗿𝘁 𝗗𝗡𝗦    :** `443, 53`
**» 𝗽𝗼𝗿𝘁 𝗧𝗟𝗦    :** `222-1000`
**» 𝗣𝗮𝘁𝗵 𝗧𝗿𝗼𝗷𝗮𝗻 :** `(/multi path)/trojan-ws`
**» 𝗨𝘀𝗲𝗿 𝗜𝗗     :** `{uuid}`
**» 𝗣𝘂𝗯 𝗞𝗲𝘆     :** {PUB}
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗪𝗦    :** 
`{b[0].replace(" ","")}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗚𝗥𝗣𝗖  :** 
`{b[1].replace(" ","")}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗙𝗼𝗿𝗺𝗮𝘁 𝗢𝗽𝗲𝗻𝗖𝗹𝗮𝘀𝗵 : https://{domain}:81/trojan-{user}.txt
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗨𝗻𝘁𝗶𝗹:** `{exp} Minutes`
**» 🍄@LITE_VERMILION**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-tro'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User `{user}` Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" TRIAL TROJAN ","trial-trojan"),
Button.inline(" CREATE TROJAN ","create-trojan")],
[Button.inline(" CHECK TROJAN ","cek-trojan"),
Button.inline(" DELETE TROJAN ","delete-trojan")],
[Button.inline(" LOCK TROJAN ","lock-trojam"),
Button.inline(" UNLOCK TROJAN ","unlock-trojan")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━☉
          🧿   𝗧𝗿𝗼𝗷𝗮𝗻 𝗠𝗮𝗻𝗮𝗴𝗲𝗿   🧿
☉━━━━━━━━━━━━━━━━━━━━━☉
✨ » 𝗦𝗲𝗿𝘃𝗶𝗰𝗲: `TROJAN`
✨ » 𝗛𝗼𝘀𝘁𝗻𝗮𝗺𝗲/𝗜𝗣: `{DOMAIN}`
✨ » 𝗜𝗦𝗣: `{z["isp"]}`
✨ » 𝗥𝗲𝗴𝗶𝗼𝗻: `{z["country"]}`
🍄 » @LITE_VERMILION
☉━━━━━━━━━━━━━━━━━━━━━☉
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
