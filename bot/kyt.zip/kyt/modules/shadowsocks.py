from kyt import *

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	async def create_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Expaired:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(3)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | bot-add-ss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**🧿   𝗦𝗛𝗗𝗪𝗦𝗖𝗦𝗞 𝗔𝗖𝗖𝗢𝗨𝗡𝗧  🧿**
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗥𝗲𝗺𝗮𝗿𝗸𝘀     :** `{user}`
**» 𝗛𝗼𝘀𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 :** `{DOMAIN}`
**» 𝗛𝗼𝘀𝘁 𝗫𝗿𝗮𝘆𝗗𝗡𝗦:** `{HOST}`
**» 𝗨𝘀𝗲𝗿 𝗤𝘂𝗼𝘁𝗮  :** `Unlimited`
**» 𝗣𝘂𝗯 𝗞𝗲𝘆     :** `{PUB}`
**» 𝗣𝗼𝗿𝘁 𝗧𝗟𝗦    :** `222-1000`
**» 𝗣𝗼𝗿𝘁 𝗚𝗥𝗣𝗖   :** `443`
**» 𝗣𝗼𝗿𝘁 𝗗𝗡𝗦    :** `443, 53`
**» 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱    :** `{uuid}`
**» 𝗖𝗶𝗽𝗲𝗿𝘀      :** `aes-128-gcm`
**» 𝗡𝗲𝘁𝗪𝗼𝗿𝗸     :** `(WS) or (gRPC)`
**» 𝗣𝗮𝘁𝗵        :** `(/multi path)/ss-ws`
**» 𝗦𝗲𝗿𝘃𝗶𝗰𝗲𝗡𝗮𝗺𝗲 :** `ss-grpc`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗧𝗟𝗦    :**
`{x[0]}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗴𝗥𝗣𝗖   :** 
`{x[1].replace(" ","")}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗝𝗦𝗢𝗡  : https://{DOMAIN}:81/ss-{user}.txt
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗨𝗻𝘁𝗶𝗹:** `{later}`
**» 🍄@LITE_VERMILION**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	async def cek_shadowsocks_(event):
		cmd = 'bot-cek-ss'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Shadowsocks**
**» 🍄@LITE_VERMILION**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	async def delete_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | del-ss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	async def trial_shadowsocks_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Expaired Minutes:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(3)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | trialss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**🧿   𝗦𝗛𝗗𝗪𝗦𝗖𝗦𝗞 𝗔𝗖𝗖𝗢𝗨𝗡𝗧  🧿**
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗥𝗲𝗺𝗮𝗿𝗸𝘀     :** `{user}`
**» 𝗛𝗼𝘀𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 :** `{DOMAIN}`
**» 𝗛𝗼𝘀𝘁 𝗫𝗿𝗮𝘆𝗗𝗡𝗦:** `{HOST}`
**» 𝗨𝘀𝗲𝗿 𝗤𝘂𝗼𝘁𝗮  :** `Unlimited`
**» 𝗣𝘂𝗯 𝗞𝗲𝘆     :** `{PUB}`
**» 𝗣𝗼𝗿𝘁 𝗧𝗟𝗦    :** `222-1000`
**» 𝗣𝗼𝗿𝘁 𝗚𝗥𝗣𝗖   :** `443`
**» 𝗣𝗼𝗿𝘁 𝗗𝗡𝗦    :** `443, 53`
**» 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱    :** `{uuid}`
**» 𝗖𝗶𝗽𝗲𝗿𝘀      :** `aes-128-gcm`
**» 𝗡𝗲𝘁𝗪𝗼𝗿𝗸     :** `(WS) or (gRPC)`
**» 𝗣𝗮𝘁𝗵        :** `(/multi path)/ss-ws`
**» 𝗦𝗲𝗿𝘃𝗶𝗰𝗲𝗡𝗮𝗺𝗲 :** `ss-grpc`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗧𝗟𝗦    :**
`{x[0]}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗴𝗥𝗣𝗖   :** 
`{x[1].replace(" ","")}`
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗟𝗶𝗻𝗸 𝗝𝗦𝗢𝗡  : https://{DOMAIN}:81/ss-{user}.txt
**☉━━━━━━━━━━━━━━━━━━━━━☉**
**» 𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗨𝗻𝘁𝗶𝗹 :** `{exp} Minutes`
**» 🍄@LITE_VERMILION**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	async def shadowsocks_(event):
		inline = [
[Button.inline(" TRIAL SHDWSCSK ","trial-shadowsocks"),
Button.inline(" CREATE SHDWSCSK ","create-shadowsocks")],
[Button.inline(" CHECK SHDWSCSK ","cek-shadowsocks"),
Button.inline(" DELETE SHDWSCSK ","delete-shadowsocks")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━☉
   🧿   𝗦𝗵𝗮𝗱𝗼𝘄𝘀𝗼𝗰𝗸𝘀 𝗠𝗮𝗻𝗮𝗴𝗲𝗿   🧿
☉━━━━━━━━━━━━━━━━━━━━━☉
✨ » 𝗦𝗲𝗿𝘃𝗶𝗰𝗲: `SHADOWSOCKS`
✨ » 𝗛𝗼𝘀𝘁𝗻𝗮𝗺𝗲/𝗜𝗣: `{DOMAIN}`
✨ » 𝗜𝗦𝗣: `{z["isp"]}`
✨ » 𝗥𝗲𝗴𝗶𝗼𝗻: `{z["country"]}`
🍄 » @LITE_VERMILION
☉━━━━━━━━━━━━━━━━━━━━━☉
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)
