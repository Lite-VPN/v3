from kyt import *

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw1:
			await event.respond("**Limit-ip:**")
			pw1 = pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw1 = (await pw1).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Expaired:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | bot-add-vle'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Klik Link di atas untuk membuka Detail Account** `{user}` **Successfully Created**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
💠               𝗫𝗿𝗮𝘆/𝗩𝗹𝗲𝘀𝘀 𝗔𝗰𝗰𝗼𝘂𝗻𝘁                💠
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗥𝗲𝗺𝗮𝗿𝗸𝘀     : `{𝘂𝘀𝗲𝗿}`
» 𝗛𝗼𝘀𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 : `{𝗗𝗢𝗠𝗔𝗜𝗡}`
» 𝗛𝗼𝘀𝘁 𝗫𝗿𝗮𝘆𝗗𝗡𝗦: `{𝗛𝗢𝗦𝗧}`
» 𝗨𝘀𝗲𝗿 𝗤𝘂𝗼𝘁𝗮  : `{𝗽𝘄} 𝗚𝗕`
» 𝗣𝗼𝗿𝘁 𝗗𝗡𝗦    : `𝟰𝟰𝟯, 𝟱𝟯`
» 𝗽𝗼𝗿𝘁 𝗧𝗟𝗦    : `𝟮𝟮𝟮-𝟭𝟬𝟬𝟬`
» 𝗣𝗼𝗿𝘁 𝗡𝗧𝗟𝗦   : `𝟴𝟬, 𝟴𝟬𝟴𝟬, 𝟴𝟬𝟴𝟭-𝟵𝟵𝟵𝟵`
» 𝗡𝗲𝘁𝗪𝗼𝗿𝗸     : `(𝗪𝗦) 𝗼𝗿 (𝗴𝗥𝗣𝗖)`
» 𝗨𝘀𝗲𝗿 𝗜𝗗     : `{𝘂𝘂𝗶𝗱}`
» 𝗣𝗮𝘁𝗵 𝗩𝗹𝗲𝘀𝘀  : `(/𝗺𝘂𝗹𝘁𝗶 𝗽𝗮𝘁𝗵)/𝘃𝗹𝗲𝘀𝘀 `
» 𝗣𝗮𝘁𝗵 𝗗𝘆𝗻𝗮𝗺𝗶𝗰: `𝗵𝘁𝘁𝗽://𝗕𝗨𝗚.𝗖𝗢𝗠/𝘃𝗹𝗲𝘀𝘀 `
» 𝗣𝘂𝗯 𝗞𝗲𝘆     : `{𝗣𝗨𝗕}`
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗟𝗶𝗻𝗸 𝗧𝗟𝗦   : 
``{𝘅[𝟬]}``
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗟𝗶𝗻𝗸 𝗡𝗧𝗟𝗦  :
``{𝘅[𝟭].𝗿𝗲𝗽𝗹𝗮𝗰𝗲(" ","")}``
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗟𝗶𝗻𝗸 𝗚𝗥𝗣𝗖  :
``{𝘅[𝟮].𝗿𝗲𝗽𝗹𝗮𝗰𝗲(" ","")}``
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗙𝗼𝗿𝗺𝗮𝘁 𝗢𝗽𝗲𝗻𝗖𝗹𝗮𝘀𝗵 : 𝗵𝘁𝘁𝗽𝘀://{𝗗𝗢𝗠𝗔𝗜𝗡}:𝟴𝟭/𝘃𝗹𝗲𝘀𝘀-{𝘂𝘀𝗲𝗿}.𝘁𝘅𝘁
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗨𝗻𝘁𝗶𝗹: `{𝗹𝗮𝘁𝗲𝗿}`
» 🍄@𝗟𝗜𝗧𝗘_𝗩𝗘𝗥𝗠𝗜𝗟𝗜𝗢𝗡

``
◇━━━━━━━━━━━━━━━━━◇
💠 𝗣𝗘𝗠𝗕𝗘𝗟𝗜𝗔𝗡 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 💠
◇━━━━━━━━━━━━━━━━━◇
-» 𝗔𝗞𝗨𝗡 : 𝗩𝗟𝗘𝗦𝗦
-» 𝗥𝗘𝗚𝗜𝗢𝗡 : {𝗰𝗶𝘁𝘆.𝘀𝘁𝗿𝗶𝗽()}
-» 𝗖𝗢𝗡𝗙𝗜𝗚 : 
-» 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : {𝘂𝘀𝗲𝗿.𝘀𝘁𝗿𝗶𝗽()}
-» 𝗗𝗘𝗩𝗜𝗖𝗘 : 𝟭 𝗜𝗣
-» 𝗛𝗔𝗥𝗚𝗔 : 
-» 𝗔𝗞𝗧𝗜𝗙 : {𝗲𝘅𝗽} 𝗛𝗔𝗥𝗜
-» 𝗧𝗚𝗟 𝗘𝗫𝗣 : {𝗹𝗮𝘁𝗲𝗿}
◇━━━━━━━━━━━━━━━━━◇
-» 🍄@𝗟𝗜𝗧𝗘_𝗩𝗘𝗥𝗠𝗜𝗟𝗜𝗢𝗡
``
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'bot-cek-vless'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vless**
**» 🍄@LITE_VERMILION**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
#LOCK vless
@bot.on(events.CallbackQuery(data=b'lock-vless'))
async def lock_vless(event):
	async def lock_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-vl'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK vless
@bot.on(events.CallbackQuery(data=b'unlock-vless'))
async def unlock_vless(event):
	async def unlock_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-vl'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-vle'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Minutes:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-trial-vle'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Klik Link di atas untuk membuka Detail Account Trial**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
💠               𝗫𝗿𝗮𝘆/𝗩𝗹𝗲𝘀𝘀 𝗔𝗰𝗰𝗼𝘂𝗻𝘁                💠
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗥𝗲𝗺𝗮𝗿𝗸𝘀     : `{𝘂𝘀𝗲𝗿}`
» 𝗛𝗼𝘀𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 : `{𝗗𝗢𝗠𝗔𝗜𝗡}`
» 𝗛𝗼𝘀𝘁 𝗫𝗿𝗮𝘆𝗗𝗡𝗦: `{𝗛𝗢𝗦𝗧}`
» 𝗨𝘀𝗲𝗿 𝗤𝘂𝗼𝘁𝗮  : `{𝗽𝘄} 𝗚𝗕`
» 𝗣𝗼𝗿𝘁 𝗗𝗡𝗦    : `𝟰𝟰𝟯, 𝟱𝟯`
» 𝗽𝗼𝗿𝘁 𝗧𝗟𝗦    : `𝟮𝟮𝟮-𝟭𝟬𝟬𝟬`
» 𝗣𝗼𝗿𝘁 𝗡𝗧𝗟𝗦   : `𝟴𝟬, 𝟴𝟬𝟴𝟬, 𝟴𝟬𝟴𝟭-𝟵𝟵𝟵𝟵`
» 𝗡𝗲𝘁𝗪𝗼𝗿𝗸     : `(𝗪𝗦) 𝗼𝗿 (𝗴𝗥𝗣𝗖)`
» 𝗨𝘀𝗲𝗿 𝗜𝗗     : `{𝘂𝘂𝗶𝗱}`
» 𝗣𝗮𝘁𝗵 𝗩𝗹𝗲𝘀𝘀  : `(/𝗺𝘂𝗹𝘁𝗶 𝗽𝗮𝘁𝗵)/𝘃𝗹𝗲𝘀𝘀 `
» 𝗣𝗮𝘁𝗵 𝗗𝘆𝗻𝗮𝗺𝗶𝗰: `𝗵𝘁𝘁𝗽://𝗕𝗨𝗚.𝗖𝗢𝗠/𝘃𝗹𝗲𝘀𝘀 `
» 𝗣𝘂𝗯 𝗞𝗲𝘆     : `{𝗣𝗨𝗕}`
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗟𝗶𝗻𝗸 𝗧𝗟𝗦   : 
``{𝘅[𝟬]}``
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗟𝗶𝗻𝗸 𝗡𝗧𝗟𝗦  :
``{𝘅[𝟭].𝗿𝗲𝗽𝗹𝗮𝗰𝗲(" ","")}``
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗟𝗶𝗻𝗸 𝗚𝗥𝗣𝗖  :
``{𝘅[𝟮].𝗿𝗲𝗽𝗹𝗮𝗰𝗲(" ","")}``
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗙𝗼𝗿𝗺𝗮𝘁 𝗢𝗽𝗲𝗻𝗖𝗹𝗮𝘀𝗵 : 𝗵𝘁𝘁𝗽𝘀://{𝗗𝗢𝗠𝗔𝗜𝗡}:𝟴𝟭/𝘃𝗹𝗲𝘀𝘀-{𝘂𝘀𝗲𝗿}.𝘁𝘅𝘁
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
» 𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗨𝗻𝘁𝗶𝗹: `{𝗹𝗮𝘁𝗲𝗿}`
» 🍄@𝗟𝗜𝗧𝗘_𝗩𝗘𝗥𝗠𝗜𝗟𝗜𝗢𝗡
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" TRIAL VLESS ","trial-vless"),
Button.inline(" CREATE VLESS ","create-vless")],
[Button.inline(" CHECK VLESS ","cek-vless"),
Button.inline(" DELETE VLESS ","delete-vless")],
[Button.inline(" LOCK VLESS ","lock-vless"),
Button.inline(" UNLOCK VLESS ","unlock-vless")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
💠              𝗧𝗥𝗢𝗝𝗔𝗡 𝗠𝗔𝗡𝗔𝗚𝗘𝗥               💠
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
🔸 » 𝗦𝗲𝗿𝘃𝗶𝗰𝗲: `𝗩𝗟𝗘𝗦𝗦`
🔸 » 𝗛𝗼𝘀𝘁𝗻𝗮𝗺𝗲/𝗜𝗣: `{DOMAIN}`
🔸 » 𝗜𝗦𝗣: `{z["isp"]}`
🔸 » 𝗡𝗘𝗚𝗔𝗥𝗔: `{z["country"]}`
🔹 » 🍄@LITE_VERMILION
☉━━━━━━━━━━━━━━━━━━━━━━━━━☉
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
